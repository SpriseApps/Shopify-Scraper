const premiumUnlockedContent = document.getElementById("premium");
const paymentForm = document.getElementById("payment");

const limitInput = document.getElementById("input-limit");

const scrapeButton = document.getElementById("button-scrape");

const mainDiv = document.getElementById("main");
const notAShopifyStore = document.getElementById("not-a-shopify-store");
const resultsDiv = document.getElementById("results");

const stopButton = document.getElementById("button-stop");
const helpButton = document.getElementById("help");
const scrapingDots = document.getElementById("scraping-dots");
let dots = 0;
let d = ["Scraping", "Scraping.", "Scraping..", "Scraping..."];
setInterval(() => {
    dots = (dots + 1) % 4;
    scrapingDots.innerText = d[dots];
}, 500);

helpButton.addEventListener("click", () => {
    chrome.tabs.create(
        {
            url: `https://mail.google.com/mail/?view=cm&fs=1&to=support@sprise.ltd`,
        },
        function () {}
    );
});

async function verifyLicense(licenseKey) {
    const res = await fetch("https://api.gumroad.com/v2/licenses/verify", {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            product_permalink: "PCWPye",
            license_key: licenseKey,
            increment_uses_count: false,
        }),
    });

    if (res.status !== 200) {
        return false;
    }

    const json = await res.json();
    return json.success;
}

window.addEventListener("load", async function (evt) {
    let storage = await chrome.storage.local.get();
    if (!(await verifyLicense(storage.license))) {
        window.location.href = "./payment.html";
    }

    if (storage.activeState) {
        resultsDiv.classList.remove("hidden");
        mainDiv.classList.add("hidden");
        return;
    }
    setTimeout(async () => {
        storage = await chrome.storage.local.get();
        console.log(storage);
        if (!storage.shopifyStore) {
            notAShopifyStore.style.display = "block";
            scrapeButton.disabled = true;
            scrapeButton.style.backgroundColor = "#a2a2a2";
        } else {
            notAShopifyStore.style.display = "none";
            scrapeButton.disabled = false;
        }
    }, 500);
});
scrapeButton.addEventListener("click", async function (evt) {
    let storage = await chrome.storage.local.get();

    if (storage.activeState) {
        return;
    }

    chrome.storage.local.set({
        activeState: {
            timestamp: new Date().getTime(),
            action: "scrape",
            shopifyStore: storage.shopifyStore,
        },
    });
});

stopButton.addEventListener("click", async function (evt) {
    chrome.storage.local.set({
        activeState: null,
    });
});

chrome.storage.local.onChanged.addListener(async function (changes, namespace) {
    if (changes.activeState) {
        const state = changes.activeState.newValue;
        if (state === null) {
            resultsDiv.classList.add("hidden");
            mainDiv.classList.remove("hidden");
            return;
        } else {
            resultsDiv.classList.remove("hidden");
            mainDiv.classList.add("hidden");

            return;
        }
    }
});
