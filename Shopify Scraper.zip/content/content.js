window.addEventListener("load", async function (evt) {
    let domain = new URL(window.location.href);
    let requestUrl = domain.origin + "/products.json?limit=250&page=1";
    let res = await fetch(requestUrl);

    if (res) {
        try {
            obj = await res.json();
            if (obj.products) {
                chrome.storage.local.set({
                    shopifyStore: domain.origin,
                    activeState: null,
                });
            } else {
                chrome.storage.local.set({
                    shopifyStore: false,
                    activeState: null,
                });
            }
        } catch (e) {
            chrome.storage.local.set({
                shopifyStore: false,
                activeState: null,
            });
        }
    }
});
let stop = false;
let scrapedProducts = [];
function initializeAll() {
    let initialize = {};
    let array = [
        "Handle",
        "Title",
        "Body (HTML)",
        "Vendor",
        "Product Type",
        "Tags",
        "Published",
        "Option1 Name",
        "Option1 Value",
        "Option2 Name",
        "Option2 Value",
        "Option3 Name",
        "Option3 Value",
        "Variant SKU",
        "Variant Grams",
        "Variant Price",
        "Variant Compare At Price",
        "Variant Image",
        "Image Src",
        "Variant Inventory Policy",
        "Variant Fulfillment Service",
        "Variant Requires Shipping",
        "Variant Taxable",
        "Variant Barcode",
        "Image Position",
        "Image Alt Text",
        "Gift Card",
        "SEO Title",
        "SEO Description",
        "Google Shopping / Google Product Category",
        "Google Shopping / Gender",
        "Google Shopping / Age Group",
        "Google Shopping / MPN",
        "Google Shopping / AdWords Grouping",
        "Google Shopping / AdWords Labels",
        "Google Shopping / Condition",
        "Google Shopping / Custom Product",
        "Google Shopping / Custom Label 0",
        "Google Shopping / Custom Label 1",
        "Google Shopping / Custom Label 2",
        "Google Shopping / Custom Label 3",
        "Google Shopping / Custom Label 4",
        "Status",
        "onlyImage",
    ];
    for (let i = 0; i < array.length; i++) {
        initialize[array[i]] = "";
    }

    return initialize;
}

function createProduct(obj) {
    let product = initializeAll();
    product["Handle"] = obj["handle"];
    product["Title"] = obj["title"];
    product["Body (HTML)"] = obj["body_html"];
    while (product["Body (HTML)"].includes(",")) {
        product["Body (HTML)"] = product["Body (HTML)"].replace(",", " ");
    }
    while (product["Body (HTML)"].includes("\n")) {
        product["Body (HTML)"] = product["Body (HTML)"].replace("\n", " ");
    }
    while (product["Body (HTML)"].includes('"')) {
        product["Body (HTML)"] = product["Body (HTML)"].replace('"', "'");
    }
    product["Vendor"] = obj["vendor"];
    product["Product Type"] = obj["product_type"];
    product["Published"] = obj["published_at"];
    product["Variant SKU"] = obj.variants[0].sku;
    product["Variant Grams"] = obj.variants[0].grams;
    product["Variant Price"] = obj.variants[0].price;
    if (obj.variants[0].featured_image) {
        product["Variant Image"] = obj.variants[0].featured_image.src;
        product["Image Position"] = obj.variants[0].featured_image.position;
    }
    product["Image Src"] = obj.images[0].src;
    product["Variant Fulfillment Service"] = "manual";
    product["Status"] = "active";
    product["Variant Inventory Policy"] = "deny";

    for (let i = 0; i < obj.options.length; i++) {
        product["Option" + obj.options[i].position + " Name"] = obj.options[i].name;
    }
    if (obj.variants[0].option1) {
        product["Option1 Value"] = obj.variants[0].option1;
    }
    if (obj.variants[0].option2) {
        product["Option2 Value"] = obj.variants[0].option2;
    }
    if (obj.variants[0].option3) {
        product["Option3 Value"] = obj.variants[0].option3;
    }

    let p = Object.keys(product);
    for (let i = 0; i < p.length; i++) {
        if (typeof product[p[i]] == "string") {
            while (product[p[i]].includes('"')) {
                product[p[i]] = product[p[i]].replace('"', "'");
            }
            while (product[p[i]].includes(",")) {
                product[p[i]] = product[p[i]].replace(",", " ");
            }
        }
    }

    scrapedProducts.push(product);
    for (let j = 1; j < obj.variants.length; j++) {
        let variant = initializeAll();
        variant["Handle"] = obj["handle"];
        if (obj.variants[j].sku != null) variant["Variant SKU"] = obj.variants[j].sku;
        variant["Variant Grams"] = obj.variants[j].grams;
        variant["Variant Price"] = obj.variants[j].price;
        if (obj.variants[j].featured_image) {
            variant["Image Src"] = obj.variants[j].featured_image.src;
            variant["Variant Image"] = obj.variants[j].featured_image.src;
            variant["Image Position"] = obj.variants[j].featured_image.position;
        }
        variant["Variant Fulfillment Service"] = "manual";
        variant["Status"] = "active";
        variant["Variant Inventory Policy"] = "deny";
        for (let i = 0; i < obj.options.length; i++) {
            variant["Option" + obj.options[i].position + " Name"] = obj.options[i].name;
        }
        if (obj.variants[0].option1) {
            variant["Option1 Value"] = obj.variants[j].option1;
        }
        if (obj.variants[0].option2) {
            variant["Option2 Value"] = obj.variants[j].option2;
        }
        if (obj.variants[0].option3) {
            variant["Option3 Value"] = obj.variants[j].option3;
        }
        p = Object.keys(variant);
        for (let i = 0; i < p.length; i++) {
            if (typeof variant[p[i]] == "string") {
                while (variant[p[i]].includes('"')) {
                    variant[p[i]] = variant[p[i]].replace('"', "'");
                }
                while (variant[p[i]].includes(",")) {
                    variant[p[i]] = variant[p[i]].replace(",", " ");
                }
            }
        }

        scrapedProducts.push(variant);
    }
    for (let j = 0; j < obj.images.length; j++) {
        let onlyImage = initializeAll();
        onlyImage["Handle"] = obj["handle"];
        onlyImage["onlyImage"] = "TRUE";
        onlyImage["Image Src"] = obj.images[j].src;
        onlyImage["Image Position"] = obj.images[j].position;
        p = Object.keys(onlyImage);
        for (let i = 0; i < p.length; i++) {
            if (typeof onlyImage[p[i]] == "string") {
                while (onlyImage[p[i]].includes('"')) {
                    onlyImage[p[i]] = onlyImage[p[i]].replace('"', "'");
                }
                while (onlyImage[p[i]].includes(",")) {
                    onlyImage[p[i]] = onlyImage[p[i]].replace(",", " ");
                }
            }
        }

        scrapedProducts.push(onlyImage);
    }
}

async function scrapeProductsFromPage(url, page) {
    if (stop == false) {
        let requestUrl = url + "/products.json?limit=250&page=" + page;
        let res = await fetch(requestUrl);
        let result = false;
        if (res) {
            try {
                obj = await res.json();
                if (obj.products.length > 0) {
                    for (let i = 0; i < obj.products.length; i++) {
                        if (stop == false) {
                            try {
                                createProduct(obj.products[i]);
                            } catch (e) {}
                        }
                    }
                    return true;
                } else {
                }
            } catch (e) {}
        } else {
        }
        return false;
    } else {
        return false;
    }
}

function csv(items, name) {
    console.log(scrapedProducts.length);
    let csv = "";
    let keysAmount = Object.keys(items[items.length - 1]).length;
    for (let row = 0; row <= items.length; row++) {
        let keysCounter = 0;
        if (row === 0) {
            for (let key in items[row]) {
                csv += key + (keysCounter + 1 < keysAmount ? "," : "\r\n");

                keysCounter++;
            }
        } else {
            for (let key in items[row - 1]) {
                csv += items[row - 1][key] + (keysCounter + 1 < keysAmount ? "," : "\r\n");
                keysCounter++;
            }
        }

        keysCounter = 0;
    }
    let link = document.createElement("a");
    link.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(csv));
    link.setAttribute("download", name);
    link.click();
}
chrome.storage.local.onChanged.addListener(async function (changes, namespace) {
    if (changes.activeState) {
        const state = changes.activeState.newValue;

        if (state === null) {
            stop = true;
            return;
        }
        const storage = await chrome.storage.local.get();
        let csvIndex = 1;
        scrapedProducts = [];
        if (storage.activeState !== null && storage.activeState.timestamp === state.timestamp && storage.shopifyStore !== false) {
            let page = 1;
            let domain = new URL(storage.shopifyStore);
            let result = await scrapeProductsFromPage(storage.shopifyStore, page);
            while (result == true && stop == false) {
                page++;
                result = await scrapeProductsFromPage(storage.shopifyStore, page);
                if (page % 20 == 0) {
                    csv(scrapedProducts, domain.host + "_" + csvIndex + ".csv");
                    csvIndex++;
                    scrapedProducts = [];
                }
            }
            if (scrapedProducts.length != 0) {
                csv(scrapedProducts, domain.host + "_" + csvIndex + ".csv");
                scrapedProducts = [];
                chrome.storage.local.set({
                    activeState: null,
                    shopifyStore: false,
                });
            } else {
                scrapedProducts = [];
                chrome.storage.local.set({
                    activeState: null,
                    shopifyStore: false,
                });
            }
        }
    }
});
